
// BubbleShootView.cpp : implémentation de la classe CBubbleShootView
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS peuvent être définis dans les gestionnaires d'aperçu, de miniature
// et de recherche d'implémentation de projet ATL, et permettent le partage de code de document avec ce projet.
#ifndef SHARED_HANDLERS
#include "BubbleShoot.h"
#endif

#include "BubbleShootDoc.h"
#include "BubbleShootView.h"
#include "Cdlgniv.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CBubbleShootView

IMPLEMENT_DYNCREATE(CBubbleShootView, CView)

BEGIN_MESSAGE_MAP(CBubbleShootView, CView)
	// Commandes d'impression standard
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CBubbleShootView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()

	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_TIMER()
END_MESSAGE_MAP()

// construction/destruction de CBubbleShootView

CBubbleShootView::CBubbleShootView() noexcept

{
	fenetre = CRect(0, 0, 1900, 900);
	rect = CRect(fenetre.CenterPoint().x - 450, fenetre.CenterPoint().y - 400, fenetre.CenterPoint().x + 450, fenetre.CenterPoint().y + 400);

}

CBubbleShootView::~CBubbleShootView()
{
}

BOOL CBubbleShootView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: changez ici la classe ou les styles Window en modifiant
	//  CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// dessin de CBubbleShootView

void CBubbleShootView::OnDraw(CDC* pDC)
{
	CBubbleShootDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	SetTimer(1, 10, NULL);



	CBrush brushfond(RGB(106, 182, 233));
	pDC -> SelectObject(&brushfond);
	pDC -> Rectangle(rect);


	pDoc->m_Tireur->setPosInitBulle(rect.CenterPoint().x, rect.bottom);

	if (pDoc->m_Partie->isUpdate())	pDoc->m_Partie->Affichage(rect, pDC);
	pDoc->m_Tireur->affichagevie(pDC);

	if (pDoc->m_Tireur->isTire())
	{
		pDoc->m_Tireur->upDateBulle(fenetre);
		pDoc->m_Tireur->afficheBulle(pDC);

	}

	pDoc->m_Tireur->afficheViseur(pDC);
}


// impression de CBubbleShootView


void CBubbleShootView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CBubbleShootView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// préparation par défaut
	return DoPreparePrinting(pInfo);
}

void CBubbleShootView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: ajoutez une initialisation supplémentaire avant l'impression
}

void CBubbleShootView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: ajoutez un nettoyage après l'impression
}

void CBubbleShootView::OnRButtonUp(UINT  nFlags , CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
	Cdlgniv dlg;
	int Result = dlg.DoModal();
	if (Result == IDOK)
	{
		if (dlg.m_choix == 1) OnBnClickedfacile();
		if (dlg.m_choix == 2) OnBnClickednormal();
		if (dlg.m_choix == 3) OnBnClickeddifficile();
	}
}

void CBubbleShootView::OnContextMenu(CWnd* pWnd , CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDD_DIALOG1, point.x, point.y, this, TRUE);
#endif
}


// diagnostics de CBubbleShootView

#ifdef _DEBUG
void CBubbleShootView::AssertValid() const
{
	CView::AssertValid();
}

void CBubbleShootView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CBubbleShootDoc* CBubbleShootView::GetDocument() const // la version non Debug est inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CBubbleShootDoc)));
	return (CBubbleShootDoc*)m_pDocument;
}
#endif //_DEBUG


// gestionnaires de messages de CBubbleShootView



void CBubbleShootView::OnBnClickedfacile()
{
	CBubbleShootDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	if (pDoc->m_Partie->m_tab != NULL) delete[] pDoc->m_Partie->m_tab;
	pDoc->m_Partie = new CPlateau(15,10,6);

	rect = CRect(fenetre.CenterPoint().x - 450, fenetre.CenterPoint().y - 400, fenetre.CenterPoint().x + 100, fenetre.CenterPoint().y + 400);

	pDoc->m_Tireur = new CTireur(6, 4);
	RedrawWindow();
}


void CBubbleShootView::OnBnClickednormal()
{
	CBubbleShootDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	if (pDoc->m_Partie->m_tab != NULL) delete[] pDoc->m_Partie->m_tab;
	pDoc->m_Partie = new CPlateau(15, 17,6);

	rect = CRect(fenetre.CenterPoint().x - 450, fenetre.CenterPoint().y - 400, fenetre.CenterPoint().x + 450, fenetre.CenterPoint().y + 400);
	pDoc->m_Tireur = new CTireur(6, 3);

	RedrawWindow();
}


void CBubbleShootView::OnBnClickeddifficile()
{
	CBubbleShootDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;
	
	if (pDoc->m_Partie->m_tab != NULL) delete[] pDoc->m_Partie->m_tab;
	pDoc->m_Partie = new CPlateau(15, 20,8);

	//pDoc->m_Partie->setdifficulte(8);
	//pDoc->m_Tireur->setdifficulte(8);

	rect = CRect(fenetre.CenterPoint().x - 450, fenetre.CenterPoint().y - 400, fenetre.CenterPoint().x + 600, fenetre.CenterPoint().y + 400);

	pDoc->m_Tireur = new CTireur(8, 2);

	RedrawWindow();

}


void CBubbleShootView::OnLButtonDown(UINT nFlags, CPoint point)
{
	CView::OnLButtonDown(nFlags, point);

	CBubbleShootDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	pDoc->m_Tireur->tire(point.x, point.y);

	RedrawWindow(0);
}


void CBubbleShootView::OnMouseMove(UINT nFlags, CPoint point)
{
	CView::OnMouseMove(nFlags, point);

	CBubbleShootDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	pDoc->m_Tireur->setPosSouris(point.x, point.y);
}


void CBubbleShootView::OnTimer(UINT_PTR nIDEvent)
{
	RedrawWindow(0);

	CView::OnTimer(nIDEvent);
}
