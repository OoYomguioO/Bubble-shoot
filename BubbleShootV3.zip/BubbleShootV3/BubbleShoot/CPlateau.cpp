#include "pch.h"
#include "CPlateau.h"
#include "time.h"


CPlateau::CPlateau()
    : m_ligne(15)
    , m_colonne(17)
    , m_score(0)
	, m_update(true)
	,m_difficulte(6)

{
	m_tab = new int[m_ligne * m_colonne];

    for (int i = 0; i < getLigne() * 2/3 * getColonne(); i++)
    {
		m_tab[i] = 1 + rand() % getm_difficulte();
    }

    for (int i = getLigne() * 2/3 * getColonne(); i < getLigne() * getColonne(); i++)
    {
		m_tab[i] = 0;
    }
}

CPlateau::CPlateau(int ln, int cl, int difficulte)
    : m_score(0)
	, m_update(true)
{
	setdifficulte(difficulte);
    setLigne(ln);
    setColonne(cl);
    
	m_tab = new int[m_ligne * m_colonne];
	m_tabDestruction = new int[0];

    for (int i = 0; i < getLigne() * 2 / 3 * getColonne(); i++)
    {
		m_tab[i] = 1 + rand() % getm_difficulte();
    }

    for (int i = getLigne() * 2 / 3 * getColonne(); i < getLigne() * getColonne(); i++)
    {
		m_tab[i] = 0;
    }
}

CPlateau::~CPlateau()
{
    delete[] m_tab;
}

int CPlateau::getLigne()
{
    return m_ligne;
}

int CPlateau::getColonne()
{
    return m_colonne;
}


int CPlateau::getScore()
{
    return m_score;
}

int CPlateau::getTab(int i)
{
    return m_tab[i];
}

int CPlateau::getTabLength()
{
    return m_ligne* m_colonne;
}

int CPlateau::getm_difficulte()
{
	return m_difficulte;
}

bool CPlateau::isUpdate()
{
	return m_update;
}

void CPlateau::setLigne(int ln)
{
	m_ligne = ln;
}

void CPlateau::setColonne(int cl)
{
	m_colonne = cl;
}

void CPlateau::setUpdate(bool up)
{
	m_update = up;
}

void CPlateau::setdifficulte(int k)
{
	m_difficulte = k;
}

void CPlateau::Affichage(CRect rect, CDC* pDC)
{


	m_update = true;

	bool lgpaire(false);

	int epaisseur = 5;
	CBrush penbleu(RGB(0, 0, 255));
	CBrush pencyan(RGB(0, 255, 255));
	CBrush penjaune(RGB(255, 255, 0));
	CBrush penrouge(RGB(255, 0, 0));
	CBrush penvert(RGB(0, 255, 0));
	CBrush penmagenta(RGB(255, 0, 255));
	CBrush penvide(RGB(255, 255, 255));
	CBrush penorange(RGB(255, 200, 0));
	CBrush penrose(RGB(255, 140, 250));

	// ---------------- affichage du tabelau -----------------

	for (int i = 0; i < this->getLigne(); i++) // ligne
	{
		if (i % 2 == 0) lgpaire = true;
		else lgpaire = false;

		for (int j = 0; j < this->getColonne(); j++) // colonne 
		{
			//-----------Pour valeurs num�riques
			//CString temp;
			//temp.Format(_T("%d"), this->getTab(i * this->getColonne() + j));

			// 1 -> bleu
			// 2 -> cyan
			// 3 -> jaune
			// 4 -> magnenta
			// 5 -> rouge
			// 6 -> vert

			if (this->getTab(i * this->getColonne() + j) == 1) CBrush* poldbrush = pDC->SelectObject(&penbleu);
			if (this->getTab(i * this->getColonne() + j) == 2) CBrush* poldbrush = pDC->SelectObject(&pencyan);
			if (this->getTab(i * this->getColonne() + j) == 3) CBrush* poldbrush = pDC->SelectObject(&penjaune);
			if (this->getTab(i * this->getColonne() + j) == 4) CBrush* poldbrush = pDC->SelectObject(&penmagenta);
			if (this->getTab(i * this->getColonne() + j) == 5) CBrush* poldbrush = pDC->SelectObject(&penrouge);
			if (this->getTab(i * this->getColonne() + j) == 6) CBrush* poldbrush = pDC->SelectObject(&penvert);
			if (this->getTab(i * this->getColonne() + j) == 7) CBrush* poldbrush = pDC->SelectObject(&penorange);
			if (this->getTab(i * this->getColonne() + j) == 8) CBrush* poldbrush = pDC->SelectObject(&penrose);
			if (this->getTab(i * this->getColonne() + j) == 0) CBrush* poldbrush = pDC->SelectObject(&penvide);


			int rayon = 50;

			if (lgpaire == false)
			{
				pDC->Ellipse((rect.TopLeft().x) + rayon * j//x1 ---
					, (rect.TopLeft().y) + rayon * i //y1
					, (rect.TopLeft().x) + rayon * (j + 1)  // x2---
					, (rect.TopLeft().y) + rayon * (i + 1)); //y2


			}

			if (lgpaire == true)
			{
				pDC->Ellipse((rect.TopLeft().x) + rayon * (j + 0.5)//x1
					, (rect.TopLeft().y) + rayon * i //y1
					, (rect.TopLeft().x) + rayon * (j + 1.5)  // x2
					, (rect.TopLeft().y) + rayon * (i + 1)); //y2
			}
		}
	}
}

void CPlateau::Destruction(int i)
{

}

/*
void CPlateau::Collision(CTireur* tir)
{
	for (int i = 0; i < getLigne(); i++)
	{
		for (int j = 0; j < getColonne(); j++)
		{
			if ((i*getLigne()+j)  )
			{
				tir->setTire(false);

				if ((tir->getPosBulleY() > centreY) && (tir->getPosBulleX() > centreX - rayon) && (tir->getPosBulleX() < centreX + rayon)) m_tab[(i + 1) * getLigne() + j] = tir->getCouleur();
				if ((tir->getPosBulleX() > centreX) && (tir->getPosBulleY() < centreY + rayon) && (tir->getPosBulleY() < centreY - rayon)) m_tab[(i)*getLigne() + j + 1] = tir->getCouleur();
				if ((tir->getPosBulleX() < centreX) && (tir->getPosBulleY() < centreY + rayon) && (tir->getPosBulleY() < centreY - rayon)) m_tab[(i)*getLigne() + j - 1] = tir->getCouleur();

			}
		}
	}
}*/

