#ifndef __CPLATEAU_H
#define __CPLATEAU_H

#include "CTireur.h"

#pragma once
class CPlateau
{
protected:
	int m_ligne;
	int m_colonne;
	
	int m_score;
	bool m_update;
	int* m_tabDestruction;
	int m_difficulte;

public:
	int* m_tab;

	CPlateau();
	CPlateau(int ln, int cl, int difficulte);
	~CPlateau();

	int getLigne();
	int getColonne();
	int getScore();
	int getTab(int i);
	int getTabLength();
	int getm_difficulte();
	bool isUpdate();

	void setLigne(int ln);
	void setColonne(int cl);
	void setUpdate(bool up);
	void setdifficulte(int k);

	void Affichage( CRect Rect, CDC* pDC);
	//void Collision(CTireur* tir);
	void Destruction(int i);
};

#endif